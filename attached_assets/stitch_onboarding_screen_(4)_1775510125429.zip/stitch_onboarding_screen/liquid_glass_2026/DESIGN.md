# Design System Specification: The Ethereal Archivist

## 1. Overview & Creative North Star

The Creative North Star for this design system is **"The Ethereal Archivist."** 

This system represents a sophisticated intersection of heritage and futurism. We are moving away from the "flatness" of the last decade and embracing a spatial computing aesthetic. By combining the warmth of a grounded, earth-toned palette (Terracotta and Cream) with the high-tech precision of "Liquid Glass," we create an interface that feels like a physical object caught in a digital light.

To break the "template" look, designers must lean into **intentional asymmetry**. Align large display serif type against narrow columns of functional sans-serif text. Use overlapping glass layers that break the traditional container grid, allowing elements to breathe across different depth planes.

---

## 2. Colors & Surface Logic

This system utilizes a tonal-first approach. Color is used to define importance and physical location in 3D space rather than just aesthetic decoration.

### The Palette
*   **Primary (Terracotta):** `#9A4100` (Container) / `#753000` (Base). This is our "human" element—warm, grounded, and authoritative.
*   **Secondary:** `#e2e2e2`. This is used for less prominent UI elements, chips, and secondary actions.
*   **Surface Base:** `#FEF9F3`. A creamy, non-white foundation that reduces eye strain and feels premium.
*   **Semantic Text:**
    *   `Text.Hero`: `#1A1A1A` (Light) / `#FFFFFF` (Dark). High-contrast, for primary headlines.
    *   `Text.Editorial`: `#4A4A4A` (Light) / `#E0E0E0` (Dark). For long-form reading and narratives.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning or grouping. 
Boundaries must be defined through background color shifts. For example, a `surface-container-low` section should sit on a `surface` background to create a "well" effect. If you feel a border is needed, you haven't used the color tokens correctly.

### Surface Hierarchy & Nesting
Treat the UI as stacked sheets of fine paper or glass:
1.  **Base Layer:** `surface` (`#FEF9F3`)
2.  **Sectioning Layer:** `surface-container-low` (`#F8F3ED`)
3.  **Interactive Layer:** `surface-container` (`#F2EDE7`)
4.  **Floating/Hero Layer:** `surface-container-highest` (`#E6E2DC`)

### The "Glass & Gradient" Rule
To achieve the 2026 "Liquid Glass" look, floating elements (modals, navigation bars, or hover states) must use:
*   **Fill:** A semi-transparent version of `surface-container-lowest` (approx. 70-80% opacity).
*   **Backdrop Blur:** A heavy `24px` to `40px` blur.
*   **Specular Highlight:** A 1px top border using `#FFFFFF` at 40% opacity. This mimics light catching the top edge of a glass pane.

---

## 3. Typography

The typographic system is a dialogue between the traditional (Noto Serif) and the functional (Inter).

*   **Headlines (Noto Serif):** Use for `display` and `headline` scales. This provides an editorial, "curated" feel. Ensure letter-spacing is slightly tightened for larger sizes to maintain tension.
*   **Functional (Inter):** Use for `title`, `body`, and `label`. Inter’s high x-height ensures legibility within glass containers and complex functional layouts.

**Hierarchy as Identity:**
*   **Display Large (3.5rem):** Reserved for singular, high-impact statements. Use `Text.Hero`.
*   **Body Medium (0.875rem):** Our workhorse. Use `Text.Editorial` to ensure a comfortable reading rhythm.

---

## 4. Elevation & Depth

We eschew traditional "drop shadows" in favor of **Tonal Layering** and **Ambient Light**.

*   **The Layering Principle:** Depth is achieved by "stacking." A card using `surface-container-lowest` placed on a `surface-container-low` section creates a soft, natural lift without a single shadow pixel.
*   **Ambient Shadows:** If an element must "float" (e.g., a primary CTA button or a modal), use an extra-diffused shadow: `box-shadow: 0 20px 40px rgba(29, 27, 24, 0.06);`. The shadow color must be a tinted version of `on-surface`, never pure black.
*   **The Specular Highlight:** For all "Liquid Glass" components, a **1px white top border** is mandatory. This is the hallmark of the system. It simulates a light source from above, giving the glass its "liquid" quality.

---

## 5. Components

### Buttons
*   **Primary:** Solid `#9A4100` (Terracotta) with `on-primary` text. Use `pill` roundness (9999pt).
*   **Secondary (Liquid Glass):** Semi-transparent `surface` with 24px backdrop blur and the 1px specular highlight. Use `md` roundness (16pt).
*   **Tertiary:** Ghost style, no background. Use `label-md` uppercase with 0.05em tracking.

### Input Fields
*   **Structure:** No bottom line. Use a `surface-container-low` fill with `sm` (8pt) roundness.
*   **Active State:** Subtle 1px specular highlight on the top and a soft `primary` glow (20% opacity) instead of a heavy stroke.

### Cards & Lists
*   **Forbid Dividers:** Do not use lines to separate list items. Use 16px or 24px of vertical white space.
*   **Container:** Use `surface-container` tiers to group content. For "Ethereal" cards, use the Liquid Glass treatment with `lg` (24pt) corner radius.

### Navigation (Spatial Bar)
*   A floating pill-shaped bar (`pill` roundness) positioned 32px from the bottom of the viewport.
*   Must use the "Liquid Glass" treatment (High blur + specular highlight).

---

## 6. Do's and Don'ts

### Do
*   **DO** use whitespace as a structural element. If a design feels cluttered, increase the spacing before adding a line. This system uses a `normal` level of spacing, providing a balanced visual density.
*   **DO** mix font weights. A `display-lg` (Noto Serif) paired with a `label-sm` (Inter, All Caps) creates a high-end editorial feel.
*   **DO** ensure the specular highlight is *only* on the top edge. Adding it to all four sides flattens the glass effect.

### Don't
*   **DON'T** use pure black (`#000000`) for text. It breaks the "Ethereal" softness. Use `Text.Hero` or `Text.Editorial`.
*   **DON'T** use the `sm` (8pt) roundness for large containers. Reserve `sm` for small inputs/chips and `lg` (24pt) for cards.
*   **DON'T** allow glass layers to become too busy. If more than three glass layers overlap, the "Liquid" effect becomes muddy; flatten the bottom-most layers to solid surface colors.