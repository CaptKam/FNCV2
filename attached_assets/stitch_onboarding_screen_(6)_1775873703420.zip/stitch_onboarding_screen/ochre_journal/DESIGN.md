Design System Specification: Fork & Compass
1. Overview & Creative North Star
Creative North Star: "The Digital Curator"
This design system moves beyond the utility of a standard recipe app to become a premium, high-end travel and food magazine. The experience is defined by intentional asymmetry, cinematic photography, and tonal depth.
We reject the "boxed-in" template look. Instead, we use a sophisticated layering of warm surfaces to create a tactile, paper-like quality. By breaking the grid with overlapping elements and dramatic typography scales, we evoke the feeling of a physical coffee-table book where every page is a curated discovery.
The Core Question: Every screen must answer: "Does this help the user get from inspiration to cooking?" If it doesn't, it doesn't belong.
2. Colors & Surface Philosophy
The palette is rooted in organic, earth-toned warmth. We use color not just for branding, but to signal hierarchy and emotional resonance.
Implementation rule: Always use the useThemeColors() hook from @/hooks/useThemeColors. NEVER write Colors.light.xxx directly in component code. This ensures dark mode works automatically.
Color Tokens
These are the values in @/constants/colors.ts. If the spec and the code disagree, update the code to match this spec, then run the app in both light and dark mode to verify.
Token Light Mode Dark Mode Role primary #9A4100 #FFB690 Active CTAs, branded accents. ONLY for interactive elements — never decorative. onPrimary #FFFFFF #552200 Text/icons on primary-colored surfaces surface #FEF9F3 #0D0D0D Main app background (NOT pure white, NOT pure black) surfaceContainerLow #F8F3ED #161B22 Cards, elevated containers, secondary sectioning surfaceContainerHigh #ECE7E2 #252A32 Higher-elevation cards, input backgrounds, avatar circles onSurface #1D1B18 #EDE0D4 Primary text — headlines, body copy. Warm near-black, not cool-toned. onSurfaceVariant #574238 #D7C2B5 Secondary text — metadata, captions, timestamps secondary #725A3C #E1C19C Metadata labels, subtle secondary elements outlineVariant #DEC1B3 #32302C "Ghost borders" — always used at 10-20% opacity, never full strength error #BA1A1A #FFB4AB Destructive actions only — delete, remove, error states success #2D7A4F #7BCC9B Completion states — recipe finished, item checked
The "No-Line" Rule
Hard rule: Never use 1px solid borders for sectioning or card definition. Boundaries are defined solely through background color shifts — a surfaceContainerLow card sitting on a surface background provides contrast without cutting the layout.
The one exception: Tab header bottom divider uses StyleSheet.hairlineWidth (0.5px) with outlineVariant at 35% opacity. This is so subtle it reads as a tonal shift, not a line.
Glassmorphism (Floating Elements)
For elements floating over images (back buttons, bookmark badges, the Discover blur header):


Fill: surface at 70% opacity

Blur: BlurView with intensity={60}, tint="systemThinMaterialDark" (on iOS)

Edge: 0.5pt stroke using outlineVariant at 15% opacity

Platform: Use expo-blur BlurView on iOS. On Android/Web, use solid surface at 90% opacity (blur is expensive on Android).
3. Typography: The Editorial Voice
A high-contrast pairing of a functional sans-serif (Inter) and a romantic serif (Noto Serif) to mirror premium print journalism.
Implementation rule: Import from @/constants/typography. NEVER hardcode fontFamily, fontSize, or lineHeight in StyleSheet.create.
Type Scale
These are the values in @/constants/typography.ts. Sizes are in points (pt), not rem — React Native uses points.
Level Token Font Size Weight Line Height Letter Spacing When To Use Display Large displayLarge Noto Serif 44pt 600 SemiBold 52 -0.5 Hero country names on the carousel Display display Noto Serif 28pt 700 Bold 34 -0.25 Recipe titles on detail screen, screen-level hero titles Headline headline Noto Serif 22pt 700 Bold 28 0 Section headers ("Tonight's Menu", "The Tasting Menu") Title title Noto Serif 18pt 500 Medium 24 0 Recipe names on cards, region names, list titles Title Medium titleMedium Inter 17pt 600 SemiBold 24 0.15 Tab header titles, button text, emphasis labels Body body Inter 17pt 400 Regular 26 0 Recipe instructions, descriptions, paragraph text Body Emphasis bodyEmphasis Inter 17pt 500 Medium 26 0 Ingredient names, day labels, highlighted info Callout callout Inter 16pt 400 Regular 22 0 Subtitles, secondary descriptions Caption caption Inter 14pt 500 Medium 20 0.1 Metadata chips, timestamps, section sub-labels Small small Inter 13pt 500 Medium 18 0.5 Badge text, tab bar labels, fine print Overline (add if missing) Inter 11pt 600 SemiBold 16 1.5 ALL CAPS category labels ("MAIN COURSE", "APPETIZER")
Minimum font size: 13pt. Nothing in the app renders below this. (Apple HIG floor is 11pt; our accessibility standard is stricter.)
Serif for meaning, sans-serif for function: Noto Serif appears ONLY on headlines, titles, and display text — the editorial voice. Inter handles everything functional — body, labels, buttons, metadata. Breaking this rule makes the app feel inconsistent.
Dark mode: Bump font weight one level. Regular → Medium. Medium → SemiBold. Dark surfaces reduce perceived weight.
Tracking on display: Tighten to -0.5 on displayLarge and -0.25 on display to give a "custom-set" magazine headline appearance. Body text uses 0 tracking for maximum readability.
4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "digital." We achieve depth through a physical stacking principle.
The Layering Principle
Treat the UI as layers of fine paper. A surface base hosts surfaceContainerLow cards. This creates a soft, natural "lift" through value contrast rather than shadow.
Surface stacking order (bottom to top):


surface (#FEF9F3) — the page

surfaceContainerLow (#F8F3ED) — cards, panels

surfaceContainerHigh (#ECE7E2) — elevated cards, input backgrounds, bottom sheets
Ambient Shadows (Use Sparingly)
If a card must float above the tonal stack (sticky bottom bars, bottom sheets, the CookingPill):


shadowColor: onSurface

shadowOffset: { width: 0, height: 12 }

shadowOpacity: 0.06

shadowRadius: 40

elevation: 3 (Android)
Light mode only. In dark mode, tonal layering handles depth — disable shadows when isDark is true.
The "Ghost Border"
For interactive inputs and subtle card edges:


outlineVariant at 10-20% opacity

0.5pt width maximum

It should be felt, not seen — if you can clearly see the border at arm's length, it's too strong.
5. Components
Buttons & Interaction
Primary CTA (Start Cooking, Submit, main flow actions):


Fill: primary color

Text: onPrimary, Inter 600 SemiBold, 17pt

Height: 52pt (meets A11Y.PRIMARY_BUTTON_HEIGHT)

Border radius: 14px

Haptic: Haptics.impactAsync(ImpactFeedbackStyle.Medium) on press

Pressed state: opacity 0.9 (or scale 0.95 if Reduce Motion is off)
Secondary Action (Add to Grocery, Save, Change Recipe):


Fill: transparent

Text: primary color, Inter 500 Medium, 15pt

Height: 44pt minimum

Border: 1px primary at 30% opacity (optional — can also be text-only)

Haptic: ImpactFeedbackStyle.Light
Destructive Action (Delete, Remove, Clear All):


Text: error color

Always requires confirmation dialog before executing

Never use error-colored backgrounds for buttons
Every button must have:


accessibilityLabel describing the action

accessibilityRole="button"

Minimum 44×44pt touch target (use hitSlop if visual is smaller)
Cards & Content
The Magazine Card (recipe cards in horizontal scrolls):


Background: surfaceContainerLow

Border radius: 16px

No visible border (the tonal shift against surface IS the border)

Internal padding: 16pt

Image aspect ratio: 16:10 (horizontal cards) or 4:5 (vertical/featured)

Image overlay: linear gradient from transparent to rgba(0,0,0,0.40) on bottom 30% — ensures white text legibility
Compact Card (list items, tasting menu rows):


Background: transparent or surfaceContainerLow

Border radius: 12px

Image: 56×56pt or 64×64pt, border radius 10-12px

Minimal padding (8-12pt)
Every card with an image must use:


expo-image (NOT react-native Image)

placeholder={{ blurhash: 'L6PZfSi_.AyE_3t7t7R**0o#DgR4' }}

onError handler (graceful fallback, never blank space)

contentFit="cover"

accessibilityLabel describing the food/scene
Dividers
Forbidden. Use vertical whitespace (32pt between major sections) to separate content. The only "divider" in the app is the whisper-thin tab header bottom border.
Immersive Components
Cultural Quote Block:


Text: headline size, Noto Serif, italic

Centered horizontally

A large opening quotation mark in primary color above the text (28pt+)

Container: surfaceContainerLow background with generous vertical padding (32pt top, 24pt bottom)
Ingredient Checkbox:


Unchecked: circular outline, outlineVariant at 25% opacity

Checked: primary fill with white checkmark

Checked text: onSurfaceVariant color with strikethrough

Haptic: ImpactFeedbackStyle.Light on toggle

Touch target: minimum 44×44pt (the circle can be 24pt visually, but the Pressable wrapper must be 44pt)
6. Do's and Don'ts
DO


DO use bleed layouts. Food photography runs edge-to-edge at the top of recipe screens and country detail screens.

DO embrace white space. If a layout feels "full," double the padding. Use 32pt or 48pt between major sections.

DO use tonal transitions. Move from surface to surfaceContainerLow for different content chapters (e.g., from editorial to ingredients).

DO add accessibilityLabel and accessibilityRole to every interactive element.

DO check useReducedMotion() before applying any scale, slide, spring, or parallax animation. Replace with opacity or instant transitions when true.

DO test every screen in dark mode after making changes.

DO use the useThemeColors() hook for all color values in components.
DON'T


DON'T use 100% black (#000000) in any mode. Light mode: use onSurface. Dark mode: use #0D0D0D for surface.

DON'T use standard iOS blue for links. Everything interactive must be primary (terracotta).

DON'T use hard borders (1px solid) to separate sections. Use tonal layering and whitespace.

DON'T hardcode Colors.light.xxx in component code. Always go through useThemeColors().

DON'T hardcode fontFamily or fontSize. Import from @/constants/typography.

DON'T build interactive elements smaller than 44×44pt.

DON'T skip the blurhash placeholder on images.

DON'T use linear easing on any visible animation.

DON'T add fonts beyond Noto Serif and Inter.

DON'T add hamburger menus, side drawers, or hide the tab bar.
7. Spacing Scale
All spacing in multiples of 4 or 8. Import from @/constants/spacing.
Token Value (pt) Use Case xs 4 Icon-to-label gaps, tight internal spacing sm 8 Between related items in a row md 12 Compact card padding, horizontal scroll card gap base 16 Standard card internal padding lg 20 Page horizontal margin — every screen, no exceptions xl 24 Between cards in vertical lists xxl 32 Between major content sections (hero) 48 Hero-to-body breathing room, page-level vertical padding
The 20pt page margin is sacred. Every screen. Every element. Left and right. If content touches the edge of the screen, it's a bug — unless it's a bleed image (hero photos, recipe card images that intentionally run edge-to-edge).
8. Animation & Feedback
Every animation communicates something. Animation as decoration is wrong.
Interaction Animation Duration Easing Reduce Motion Fallback Button press Scale to 0.95 150ms ease-in opacity: 0.85 only Navigate forward Slide right 320ms ease-out (decelerate) Instant cut Navigate back Slide left 320ms ease-in (accelerate) Instant cut Bottom sheet open Slide up 400ms cubic-bezier ease-out Instant appear Toast appear Fade in 200ms ease-out Instant appear Toast dismiss Fade out 200ms ease-in Instant disappear Image load Crossfade from blurhash 400ms ease-out Instant swap (transition={0}) Error 3 horizontal shakes 300ms total spring Red border flash only Success Checkmark scale 0→1 300ms spring Instant appear
Hard rules:


NEVER use linear easing on visible animations

Spring easing: only for interactive drag, rubber-band, and swipe dismiss

Haptic on every primary action: ImpactFeedbackStyle.Medium

Haptic on every secondary action: ImpactFeedbackStyle.Light
9. Accessibility Requirements (App Store Review)
These are not optional polish. Apple reviewers check for these.
Requirement Rule Consequence of Violation Touch targets Every interactive element ≥ 44×44pt App Store rejection VoiceOver labels Every Pressable has accessibilityLabel + accessibilityRole App Store rejection Dynamic Type Text scales with user's preferred size setting App Store rejection Color contrast 4.5:1 for normal text, 3:1 for 18pt+ (WCAG AA) App Store rejection Reduce Motion Every animated screen checks useReducedMotion() App Store rejection Dark Mode All colors via useThemeColors(), tested separately Negative reviews, possible rejection Color not sole indicator Pair color with icon, label, or shape for meaning Accessibility violation
10. Implementation Checklist
Run through this before any PR or commit:


[ ] All colors via useThemeColors() — no Colors.light.xxx in component code
[ ] All typography via @/constants/typography — no inline fontFamily/fontSize
[ ] All spacing via @/constants/spacing — no magic numbers
[ ] All images via expo-image with blurhash + onError
[ ] All interactive elements ≥ 44×44pt touch target
[ ] All interactive elements have accessibilityLabel + accessibilityRole
[ ] useReducedMotion() checked on every animated screen
[ ] Tested in light mode and dark mode
[ ] No hard borders (1px solid) separating sections
[ ] No fonts other than Noto Serif and Inter
[ ] Page margins are 20pt left and right
[ ] Haptic feedback on primary and secondary actions